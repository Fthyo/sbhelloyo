## FGM SELFBOT LINE

- Official SelfBot Script 2020.
- Work 100% & Safe From Banned.
- Created By: Hansen Gianto & UNYPASS
- Special Thanks: HW & BE-TEAM

## INSTALL COMMAND FOR TERMUX

```sh
Untuk Command/Perintah Cara Menjalankan Bot Silahkan Cek Video Youtube Dibawah
```

## Video Tutorial Full
[CLICK HERE](https://youtube.com/hansengianto)

## FGM OPENCHAT
[CLICK HERE](https://hansengianto.gq/square.html)


Ⓒ FGM Bot 2020
